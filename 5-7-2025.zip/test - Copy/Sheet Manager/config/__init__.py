"""
Configuration package for the Sheets Manager application.
"""
